#__init__.py

#Version of the twisties package
__version__ = "1.0.0"